solver_types = [
    ("wcsph_method", "Weakly Compressible SPH", '', '', 0),
    ("pcisph_method", "Predictive-Corrective Incompressible SPH", '', '', 1),
    ("dfsph_method", "Divergence-Free SPH", '', '', 2)
]

fluid_unit_types = [
    ("fu_fluid_block_type", "Fluid block", '', '', 0),
    ("fu_geometry_type", "Geometry", '', '', 2),
    ("fu_emitter_type", "Emitter", '', '', 1)
]

boundary_unit_types = [
    ("bu_box_type", "Box", '', '', 0),
    ("bu_sphere_type", "Sphere", '', '', 2),
    ("bu_geometry_type", "Geometry", '', '', 1)
]

boundary_handling_types = [
    ("none_boundary_method", "None", '', '', 0),
    ("cube_boundary_method", "Simple boundary handling", '', '', 1),
    ("pcisph_boundary_method", "PCISPH boundary handling", '', '', 2),
    ("akinci_boundary_method", "Akinci boundary handling", '', '', 3)
]

emitter_types = [
    ("none_emitter", "None", '', '', 0),
    ("square_emitter", "Square emitter", '', '', 1),
    ("circle_emitter", "Circle emitter", '', '', 2)
]

viscosity_types = [
    ("none_visco_method", "None", '', '', 0),
    ("standard_visco_method", "Standard Viscosity", '', '', 1),
    ("artificial_visco_method", "Artificial Viscosity", '', '', 2),
    ("xsph_visco_method", "XSPH Viscosity", '', '', 3)
]

surften_types = [
    ("none_st_method", "None", '', '', 0),
    ("akinci_st_method", "Akinci Surface Tension", '', '', 1)
]

adhesion_types = [
    ("none_adhesion_method", "None", '', '', 0),
    ("akinci_adhesion_method", "Akinci Adhesion", '', '', 1)
]
