import bpy
from bpy_extras.io_utils import ImportHelper
from bpy.types import Operator, OperatorFileListElement
from bpy.props import CollectionProperty

from . import fileio as io
from . import types

class readFramesOp(Operator, ImportHelper):
    bl_idname = "sph.readframes"
    bl_label = "Read frames"
    
    files : CollectionProperty(name='File paths', type=OperatorFileListElement)
    
    def execute(self, context):
        io.read_frames(context, self.files, self.filepath)
        
        return {"FINISHED"}

class createSceneOp(Operator):
    bl_idname = "sph.createscene"
    bl_label = "Create new scene"

    def execute(self, context):
        obj = context.object
        obj.sph_created = True
        
        obj.sph_fluid_set.fs_list.add()
        obj.sph_fluid_set.fm_index = 0
        obj.display_type = 'WIRE'

        return {"FINISHED"}

class importSceneOp(Operator, ImportHelper):
    bl_idname = "sph.importscene"
    bl_label = "Import scene"

    def execute(self, context):
        obj = context.object
        obj.sph_created = True
        obj.display_type = 'WIRE'
        
        io.import_config(obj, self.filepath)

        return {"FINISHED"}

class exportSceneOp(Operator):
    bl_idname = "sph.exportscene"
    bl_label = "Export scene"

    def execute(self, context):

        return io.export_config(context.object)

class deleteSceneOp(Operator):
    bl_idname = "sph.deletescene"
    bl_label = "Delete scene"

    def execute(self, context):
        obj = context.object
        obj.sph_created = False

        # Resetear fluid set y boundary set
        # Eliminar objetos asociados
        obj.sph_fluid_set.clear() 
        obj.sph_boundary_set.clear() 
        obj.sph_fluid_set.multiphase = False
        
        # no borra los objetos asociados a los fluid units
        obj.sph_fluid_set.fs_list.clear()    
        obj.sph_boundary_set.bs_list.clear() 
        
        obj.display_type = 'TEXTURED'

        return {"FINISHED"}

class addFluidModelOp(Operator):
    bl_idname = "sph.addfluidmodel"
    bl_label = ""

    def execute(self, context):
        fs_list = context.object.sph_fluid_set.fs_list
        fm_index = context.object.sph_fluid_set.fm_index
        
        new_index = len(fs_list)
        fs_list.add()
        context.object.sph_fluid_set.fm_index = new_index

        return{'FINISHED'}


# Borrar fluidModel
class removeFluidModelOp(Operator):

    bl_idname = "sph.removefluidmodel"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return context.object.sph_fluid_set.fs_list

    def execute(self, context):
        fs_list = context.object.sph_fluid_set.fs_list
        index = context.object.sph_fluid_set.fm_index
        fm = fs_list[index]

        # Eliminar objetos asociados
        fm.clear()
                
        fs_list.remove(index)
        context.object.sph_fluid_set.fm_index = min(max(0, index - 1), len(fs_list) - 1)

        return{'FINISHED'}


# Añadir fluid unit
class addFluidUnitOp(Operator):
    bl_idname = "sph.addfluidunit"
    bl_label = ""

    def execute(self, context):
        fm_index = context.object.sph_fluid_set.fm_index
        fm = context.object.sph_fluid_set.fs_list[fm_index]
        fm.fm_list.add()
        fm.fu_index = len(fm.fm_list) - 1

        if fm.current_fu_type == types.fluid_unit_types[0][0]: # fluid block
            # guardar objeto activo antes de crear el nuevo cubo
            nameActiveObject = context.view_layer.objects.active.name

            # crear el cubo
            bpy.ops.mesh.primitive_cube_add(size=0.5, enter_editmode=False, align="WORLD", location=(0, 0, 0), scale=(1, 1, 1))
            context.view_layer.objects.active.name = "Fluid block"

            # Guardar en el fluid unit una referencia al objeto que lo representa y su tipo
            fm.fm_list[len(fm.fm_list) - 1].object = context.view_layer.objects.active
            fm.fm_list[len(fm.fm_list) - 1].fu_type = fm.current_fu_type

            # reestablecer el objeto activo
            context.view_layer.objects.active = bpy.data.objects[nameActiveObject]


        elif fm.current_fu_type == types.fluid_unit_types[1][0]: # geometry
            fm.fm_list[len(fm.fm_list) - 1].fu_type = fm.current_fu_type
        elif fm.current_fu_type == types.fluid_unit_types[2][0]: # emmiter
            fm.fm_list[len(fm.fm_list) - 1].fu_type = fm.current_fu_type

        return{'FINISHED'}


# Borrar fluidUnit
class removeFluidUnitOp(Operator):

    bl_idname = "sph.removefluidunit"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        fm = context.object.sph_fluid_set.fs_list[context.object.sph_fluid_set.fm_index]
        return fm.fm_list

    def execute(self, context):
        fm = context.object.sph_fluid_set.fs_list[context.object.sph_fluid_set.fm_index]
        fm_list = fm.fm_list
        index = fm.fu_index

        # Eliminar objetos asociados
        fm_list[index].clear()

        # borrar elemento de la lista
        fm_list.remove(index)
        fm.fu_index = min(max(0, index - 1), len(fm_list) - 1)

        return{'FINISHED'}

# Añadir boundary unit
class addBoundaryUnitOp(Operator):
    bl_idname = "sph.addboundaryunit"
    bl_label = ""

    def execute(self, context):
        bm_index = context.object.sph_boundary_set.bm_index
        bm = context.object.sph_boundary_set.bs_list[bm_index]
        bm.bm_list.add()
        bm.bu_index = len(bm.bm_list) - 1

        if bm.current_bu_type == types.boundary_unit_types[0][0]: # box
             # guardar objeto activo antes de crear el nuevo cubo
            nameActiveObject = context.view_layer.objects.active.name

            # crear el cubo
            bpy.ops.mesh.primitive_cube_add(size=0.5, enter_editmode=False, align="WORLD", location=(0, 0, 0), scale=(1, 1, 1))
            context.view_layer.objects.active.name = "Boundary cube"

            # Guardar en el fluid unit una referencia al objeto que lo representa y su tipo
            bm.bm_list[len(bm.bm_list) - 1].object = context.view_layer.objects.active
            bm.bm_list[len(bm.bm_list) - 1].bu_type = bm.current_bu_type

            # reestablecer el objeto activo
            context.view_layer.objects.active = bpy.data.objects[nameActiveObject]

        elif bm.current_bu_type == types.boundary_unit_types[1][0]: # sphere
            # guardar objeto activo antes de crear el nuevo cubo
            nameActiveObject = context.view_layer.objects.active.name

            # crear el cubo
            bpy.ops.mesh.primitive_uv_sphere_add(radius=0.5, enter_editmode=False, align="WORLD", location=(0, 0, 0), scale=(1, 1, 1))
            context.view_layer.objects.active.name = "Boundary sphere"

            # Guardar en el fluid unit una referencia al objeto que lo representa y su tipo
            bm.bm_list[len(bm.bm_list) - 1].object = context.view_layer.objects.active
            bm.bm_list[len(bm.bm_list) - 1].bu_type = bm.current_bu_type

            # reestablecer el objeto activo
            context.view_layer.objects.active = bpy.data.objects[nameActiveObject]

        elif bm.current_bu_type == types.boundary_unit_types[2][0]: # geometry
            bm.bm_list[len(bm.bm_list) - 1].bu_type = bm.current_bu_type

        return{'FINISHED'}


# Borrar boundaryUnit
class removeBoundaryUnitOp(Operator):

    bl_idname = "sph.removeboundaryunit"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        bm = context.object.sph_boundary_set.bs_list[context.object.sph_boundary_set.bm_index]
        return bm.bm_list

    def execute(self, context):
        bm = context.object.sph_boundary_set.bs_list[context.object.sph_boundary_set.bm_index]
        bm_list = bm.bm_list
        index = bm.bu_index

        # Eliminar objetos asociados
        bm_list[index].clear()

        # borrar elemento de la lista
        bm_list.remove(index)
        bm.bu_index = min(max(0, index - 1), len(bm_list) - 1)

        return{'FINISHED'}


# Añadir boundadary model
class addBoundaryModelOp(Operator):
    bl_idname = "sph.addboundarymodel"
    bl_label = ""

    def execute(self, context):
        bs_list = context.object.sph_boundary_set.bs_list
        bs_list.add()
        context.object.sph_boundary_set.bm_index = len(bs_list) - 1

        return{'FINISHED'}


# Borrar boundary Model
class removeBoundaryModelOp(Operator):

    bl_idname = "sph.removeboundarymodel"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return context.object.sph_boundary_set.bs_list

    def execute(self, context):
        bs_list = context.object.sph_boundary_set.bs_list
        index = context.object.sph_boundary_set.bm_index
        bm = bs_list[index]
        
        bm.clear()

        bs_list.remove(index)
        context.object.sph_boundary_set.bm_index = min(max(0, index - 1), len(bs_list) - 1)

        return{'FINISHED'} 
