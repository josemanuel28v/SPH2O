bl_info = {
    "name": "SPH Solver",
    "author": "José Manuel Valverde Pérez",
    "version": (1, 0),
    "blender": (2, 93, 0),
    "location": "Properties > Physics",
    "description": "SPH solver for Blender scenes",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Physics"
}

if "bpy" in locals():
    import importlib
    if "types" in locals():
        importlib.reload(types)
    if "functions" in locals():
        importlib.reload(functions)
    if "ops" in locals():
        importlib.reload(ops)
    if "props" in locals():
        importlib.reload(props)
else:
    from . import types
    from . import functions
    from . import operators as ops
    from . import properties as props

import bpy
from bpy.types import UIList, Panel
from bpy.utils import unregister_class, register_class
from bpy.props import BoolProperty, PointerProperty


# UILISTS

class FluidSetList(UIList):
    bl_idname = "OBJECT_UL_fluidsetlist"

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):

        custom_icon = 'MATFLUID'

        # Make sure your code supports all 3 layout types
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            split = layout.split()
            split.prop(item, "name", emboss=False, icon=custom_icon)

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            split = layout.split()
            split.prop(item, "name", emboss=False, icon=custom_icon)


class FluidModelList(UIList):
    bl_idname = "OBJECT_UL_fluidmodellist"

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):
        custom_icon = 'UNLINKED'
        # comprobar si sirve de algo para cuando el objeto es none
        if item.object is not None:
            if item.fu_type == types.fluid_unit_types[0][0]: # fluid block
                custom_icon = 'CUBE'
            
            elif item.fu_type == types.fluid_unit_types[1][0]: # Geometry
                custom_icon = 'MESH_MONKEY'

            elif item.fu_type == types.fluid_unit_types[2][0]: # Emitter
                
                if item.emitter_type == types.emitter_types[1][0]: #square
                    custom_icon = 'MESH_PLANE'
                elif item.emitter_type == types.emitter_types[2][0]: #circle
                    custom_icon = 'MESH_CIRCLE'
                    
            split = layout.split()
            split.prop(item.object, "name", text="", emboss=False, icon=custom_icon)

        else:

            split = layout.split()

            if item.fu_type == types.fluid_unit_types[1][0]: # Geometry
                split.label(text="Empty geometry", icon=custom_icon)

            elif item.fu_type == types.fluid_unit_types[2][0]: # Emitter                
                split.label(text="Empty emitter", icon=custom_icon)

class BoundarySetList(UIList):
    bl_idname = "OBJECT_UL_boundarysetlist"

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):

        # We could write some code to decide which icon to use here...
        custom_icon = 'RIGID_BODY'

        # Make sure your code supports all 3 layout types
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            split = layout.split()
            split.prop(item, "name", emboss=False, icon=custom_icon)

        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            split = layout.split()
            split.prop(item, "name", emboss=False, icon=custom_icon)

class BoundaryModelList(UIList):
    bl_idname = "OBJECT_UL_boundarymodellist"

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):
        custom_icon = 'UNLINKED'

        if item.object is not None:

            if item.bu_type == types.boundary_unit_types[0][0]: # box
                custom_icon = 'CUBE'
            elif item.bu_type == types.boundary_unit_types[1][0]: # Sphere
                custom_icon = 'SPHERE'
            elif item.bu_type == types.boundary_unit_types[2][0]: # geometry
                custom_icon = 'MESH_MONKEY'

            split = layout.split()
            split.prop(item.object, "name", text="", emboss=False, icon=custom_icon)

        else:

            split = layout.split()

            if item.bu_type == types.boundary_unit_types[2][0]: # geometry
                split.label(text="Empty geometry", icon=custom_icon)

# PANELS

# Panel del que heredan todos los demas
class MyPanel(Panel):
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "physics"

# Panel principal que contiene los demas panels
class MainPanel(MyPanel):
    bl_label = "SPH Fluid"
    bl_idname = "OBJECT_PT_sph_main"
    bl_icon = "ADD"


    def draw(self, context):
        obj = context.object
        layout = self.layout

        if obj.sph_created is False:
            split = layout.split()

            col = split.column()
            col.operator("sph.createscene", icon="ADD")

            col = split.column()
            col.operator("sph.importscene", icon="IMPORT")
        else:
            split = layout.split()
            col = split.column();
            col.operator("sph.deletescene", icon="TRASH")

            col = split.column()
            col.operator("sph.exportscene", icon="EXPORT")
            
            row = layout.row()
            row.operator("sph.readframes", icon="RENDER_ANIMATION")

# Subpanel para la configuracion general
class GeneralConfPanel(MyPanel):
    bl_label = "General configuration"
    bl_parent_id = "OBJECT_PT_sph_main"
    bl_idname = "OBJECT_PT_sph_general_conf"

    @classmethod
    def poll(self, context):
        return context.object.sph_created

    def draw(self, context):
            obj = context.object
            layout = self.layout
            #layout.use_property_split = True # Otra distribucion
            #layout.use_property_decorate = False

            if obj.sph_created is True:

                split = layout.split()

                col = split.column()
                col.prop(obj.sph_scene_data, "startTime")

                col = split.column()
                col.prop(obj.sph_scene_data, "endTime")

                split = layout.split()

                col = split.column()
                col.prop(obj.sph_scene_data, "timeStep")

                col = split.column()
                col.prop(obj.sph_scene_data, "fps")

                split = layout.split()

                col = split.column()
                col.prop(obj.sph_scene_data, "minTimeStep")

                col = split.column()
                col.prop(obj.sph_scene_data, "maxTimeStep")

                row = layout.row()
                row.prop(obj.sph_scene_data, "particleRadius")

                row = layout.row()
                row.prop(obj.sph_scene_data, "gravity")

# Subpanel para los parametros del solver
class solverSubPanel(MyPanel):
    bl_label = "Solver"
    bl_parent_id = "OBJECT_PT_sph_main"
    bl_idname = "OBJECT_PT_sph_solver"

    @classmethod
    def poll(self, context):
        return context.object.sph_created

    def draw(self, context):
        obj = context.object
        layout = self.layout
        layout.use_property_decorate = False

        if obj.sph_created is True:
            row = layout.row()
            row.prop(obj.sph_scene_data, "simulationMethod")
            simulationMethod = obj.sph_scene_data.simulationMethod
            layout.use_property_split = True # Otra distribucion
            if simulationMethod == "wcsph_method":

                row = layout.row()
                row.prop(obj.sph_scene_data, "stiffness")

                row = layout.row()
                row.prop(obj.sph_scene_data, "gamma")

                row = layout.row()
                row.prop(obj.sph_scene_data, "cflFactor")

            elif  simulationMethod == "pcisph_method":

                row = layout.row()
                row.prop(obj.sph_scene_data, "etaPCI")
                
                row = layout.row()
                row.prop(obj.sph_scene_data, "minIterationsPCI")
                
                row = layout.row()
                row.prop(obj.sph_scene_data, "maxIterationsPCI")

                row = layout.row()
                row.prop(obj.sph_scene_data, "cflFactor")

            elif  simulationMethod == "dfsph_method":

                row = layout.row()
                row.prop(obj.sph_scene_data, "eta")
                
                row = layout.row()
                row.prop(obj.sph_scene_data, "minIterationsDF")
                
                row = layout.row()
                row.prop(obj.sph_scene_data, "maxIterationsDF")

                row = layout.row()
                row.prop(obj.sph_scene_data, "cflFactor")
                
                row = layout.row()
                row.prop(obj.sph_scene_data, "divSolver")
                
                if obj.sph_scene_data.divSolver == True:
                    
                    row = layout.row()
                    row.prop(obj.sph_scene_data, "etaV")
                    
                    row = layout.row()
                    row.prop(obj.sph_scene_data, "minIterationsDFV")
                    
                    row = layout.row()
                    row.prop(obj.sph_scene_data, "maxIterationsDFV")
                    
                    

# Sub panel para el fluid set
class fluidSetSubPanel(MyPanel):
    bl_label = "Fluid Set"
    bl_parent_id = "OBJECT_PT_sph_main"
    bl_idname = "OBJECT_PT_sph_fluid_set"

    @classmethod
    def poll(self, context):
        return context.object.sph_created

    def draw(self, context):
        obj = context.object
        layout = self.layout
        layout.use_property_split = True # Otra distribucion
        layout.use_property_decorate = False

        if obj.sph_created is True:
            row = layout.row()
            row.prop(obj.sph_fluid_set, "viscosityMethod")
            row = layout.row()
            row.prop(obj.sph_fluid_set, "surftenMethod")
            row = layout.row()
            row.prop(obj.sph_fluid_set, "adhesionMethod")
            row = layout.row()
            row.prop(obj.sph_fluid_set, "multiphase")
            
            if obj.sph_fluid_set.multiphase:
                
                # FluidSet of Fluid Models
                row = layout.row()
                row.template_list("OBJECT_UL_fluidsetlist", "The_List", obj.sph_fluid_set,
                                  "fs_list", obj.sph_fluid_set, "fm_index")
       
                col = row.column(align=True)
                col.operator("sph.addfluidmodel", icon="ADD")
                col.operator("sph.removefluidmodel", icon="REMOVE")


            if obj.sph_fluid_set.fm_index >= 0 and obj.sph_fluid_set.fs_list:
                fm = obj.sph_fluid_set.fs_list[obj.sph_fluid_set.fm_index]
                
                row = layout.row()
                row.prop(fm, "density0")

                row = layout.row()
                row.prop(fm, "viscosity")

                row = layout.row()
                row.prop(fm, "bviscosity")

                row = layout.row()
                row.prop(fm, "surften")

                row = layout.row()
                row.prop(fm, "adhesion")

                # FluidModel of Fluid Units                                  
                row = layout.row()
                col = row.column()
                col.template_list("OBJECT_UL_fluidmodellist", "The_List", fm,
                              "fm_list", fm, "fu_index")
                              
                col = col.row()
                col.use_property_split = False
                col.prop(fm, "current_fu_type", expand=True)
                              
                col = row.column(align=True)
                col.operator("sph.addfluidunit", icon="ADD")
                col.operator("sph.removefluidunit", icon="REMOVE")

                if fm.fu_index >= 0 and fm.fm_list:
                    fu = fm.fm_list[fm.fu_index]

                    if fu.fu_type == types.fluid_unit_types[0][0]: # fluid block

                        row = layout.row()
                        row.prop(fu.object, "location")

                        row = layout.row()
                        row.prop(fu.object, "rotation_euler")

                        row = layout.row()
                        row.prop(fu.object, "scale")

                    elif fu.fu_type == types.fluid_unit_types[1][0]: # geometry

                        layout.use_property_split = False
                        row = layout.row()
                        row.prop_search(fu, "object", context.scene, "objects")
                        layout.use_property_split = True

                        if fu.object is not None:

                            row = layout.row()
                            row.prop(fu.object, "location")

                            row = layout.row()
                            row.prop(fu.object, "rotation_euler")

                            row = layout.row()
                            row.prop(fu.object, "scale")

                    elif fu.fu_type == types.fluid_unit_types[2][0]: # emitter

                        if fu.object is None:
                            row = layout.row()
                            row.prop(fu, "emitter_type")

                            row = layout.row()
                            row.prop(fu, "startTime")

                            row = layout.row()
                            row.prop(fu, "velocity")

                            row = layout.row()
                            row.prop(fu, "numParticles")
                            
                            row = layout.row()
                            row.prop(fu, "spacing")

                        else:

                            row = layout.row()
                            row.prop(fu, "startTime")

                            row = layout.row()
                            row.prop(fu, "velocity")

                            row = layout.row()
                            row.prop(fu, "numParticles")
                            
                            row = layout.row()
                            row.prop(fu, "spacing")

                            row = layout.row()
                            row.prop(fu.object, "location")

                            row = layout.row()
                            row.prop(fu.object, "rotation_euler")

                            row = layout.row()
                            row.prop(fu.object, "scale")

# Subpanel para el Boundary set
class boundarySetSubPanel(MyPanel):
    bl_label = "Boundary Set"
    bl_parent_id = "OBJECT_PT_sph_main"
    bl_idname = "OBJECT_PT_sph_boundary_set"

    @classmethod
    def poll(self, context):
        return context.object.sph_created

    def draw(self, context):
        obj = context.object
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        

        if obj.sph_created is True:
            row = layout.row()
            row.prop(obj.sph_boundary_set, "boundaryMethod")

            if obj.sph_boundary_set.boundaryMethod != types.boundary_handling_types[0][0]:

                row = layout.row()
                row.template_list("OBJECT_UL_boundarysetlist", "The_List", obj.sph_boundary_set,
                              "bs_list", obj.sph_boundary_set, "bm_index")

                col = row.column(align=True)
                col.operator("sph.addboundarymodel", icon="ADD")
                col.operator("sph.removeboundarymodel", icon="REMOVE")

            if obj.sph_boundary_set.bm_index >= 0 and obj.sph_boundary_set.bs_list:
                bm = obj.sph_boundary_set.bs_list[obj.sph_boundary_set.bm_index]

                row = layout.row()
                col = row.column()
                col.template_list("OBJECT_UL_boundarymodellist", "The_List", bm,
                              "bm_list", bm, "bu_index")
                              
                col = col.row()
                col.use_property_split = False
                col.prop(bm, "current_bu_type", expand=True)
                              
                col = row.column(align=True)
                col.operator("sph.addboundaryunit", icon="ADD")
                col.operator("sph.removeboundaryunit", icon="REMOVE")

                if bm.bu_index >= 0 and bm.bm_list:
                    bu = bm.bm_list[bm.bu_index]

                    if bu.bu_type == types.boundary_unit_types[0][0]: # box

                        if obj.sph_boundary_set.boundaryMethod == types.boundary_handling_types[2][0]:
                            row = layout.row()
                            row.prop(bu, "inverted")

                        row = layout.row()
                        row.prop(bu.object, "location")

                        row = layout.row()
                        row.prop(bu.object, "rotation_euler")

                        row = layout.row()
                        row.prop(bu.object, "scale")

                    elif bu.bu_type == types.boundary_unit_types[1][0]: # sphere
                        
                        if obj.sph_boundary_set.boundaryMethod == types.boundary_handling_types[2][0]:
                            row = layout.row()
                            row.prop(bu, "inverted")

                        row = layout.row()
                        row.prop(bu.object, "location")

                        row = layout.row()
                        row.prop(bu.object, "rotation_euler")

                        row = layout.row()
                        row.prop(bu.object, "scale")

                    elif bu.bu_type == types.boundary_unit_types[2][0]: # geometry

                        layout.use_property_split = False
                        row = layout.row()
                        row.prop_search(bu, "object", context.scene, "objects")
                        layout.use_property_split = True

                        if bu.object is not None:

                            row = layout.row()
                            row.prop(bu, "spacing")

                            row = layout.row()
                            row.prop(bu.object, "location")

                            row = layout.row()
                            row.prop(bu.object, "rotation_euler")

                            row = layout.row()
                            row.prop(bu.object, "scale")


############################### OPERADORES


def register():
    register_class(MainPanel)
    register_class(GeneralConfPanel)
    register_class(solverSubPanel)
    register_class(fluidSetSubPanel)
    register_class(boundarySetSubPanel)

    register_class(props.SceneInfo)
    register_class(props.FluidUnit)
    register_class(props.FluidModel)
    register_class(props.FluidSet)
    register_class(props.BoundaryUnit)
    register_class(props.BoundaryModel)
    register_class(props.BoundarySet)

    register_class(ops.createSceneOp)
    register_class(ops.importSceneOp)
    register_class(ops.exportSceneOp)
    register_class(ops.deleteSceneOp)
    register_class(ops.readFramesOp)
    register_class(ops.addFluidModelOp)
    register_class(ops.removeFluidModelOp)
    register_class(ops.addBoundaryModelOp)
    register_class(ops.removeBoundaryModelOp)
    register_class(ops.addFluidUnitOp)
    register_class(ops.removeFluidUnitOp)
    register_class(ops.addBoundaryUnitOp)
    register_class(ops.removeBoundaryUnitOp)

    register_class(FluidSetList)
    register_class(FluidModelList)
    register_class(BoundarySetList)
    register_class(BoundaryModelList)

    bpy.types.Object.sph_modified = BoolProperty(name = "SPH Scene modified", default = False)
    bpy.types.Object.sph_created = BoolProperty(name = "SPH Scene created", default = False)
    bpy.types.Object.sph_scene_data = PointerProperty(type=props.SceneInfo)
    bpy.types.Object.sph_fluid_set = PointerProperty(type=props.FluidSet)
    bpy.types.Object.sph_boundary_set = PointerProperty(type=props.BoundarySet)
    

def unregister():
    unregister_class(MainPanel)
    unregister_class(GeneralConfPanel)
    unregister_class(solverSubPanel)
    unregister_class(fluidSetSubPanel)
    unregister_class(boundarySetSubPanel)

    unregister_class(props.SceneInfo)
    unregister_class(props.FluidUnit)
    unregister_class(props.FluidModel)
    unregister_class(props.FluidSet)
    unregister_class(props.BoundaryUnit)
    unregister_class(props.BoundaryModel)
    unregister_class(props.BoundarySet)

    unregister_class(ops.createSceneOp)
    unregister_class(ops.importSceneOp)
    unregister_class(ops.exportSceneOp)
    unregister_class(ops.deleteSceneOp)
    unregister_class(ops.readFramesOp)
    unregister_class(ops.addFluidModelOp)
    unregister_class(ops.removeFluidModelOp)
    unregister_class(ops.addBoundaryModelOp)
    unregister_class(ops.removeBoundaryModelOp)
    unregister_class(ops.addFluidUnitOp)
    unregister_class(ops.removeFluidUnitOp)
    unregister_class(ops.addBoundaryUnitOp)
    unregister_class(ops.removeBoundaryUnitOp)

    unregister_class(FluidSetList)
    unregister_class(FluidModelList)
    unregister_class(BoundarySetList)
    unregister_class(BoundaryModelList)

    del bpy.types.Object.sph_scene_data
    del bpy.types.Object.sph_fluid_set
    del bpy.types.Object.sph_boundary_set
    del bpy.types.Object.sph_modified
    del bpy.types.Object.sph_created


if __name__ == "__main__" :
    register()



