import bpy
from bpy.props import StringProperty, IntProperty, CollectionProperty, FloatProperty, FloatVectorProperty, EnumProperty, BoolProperty, PointerProperty
from bpy.types import PropertyGroup
from . import functions
from . import types

class SceneInfo(PropertyGroup):

    startTime : FloatProperty(name="Start time",default=0.0, update=functions.set_modified)
    endTime : FloatProperty(name="End time", default=5.0, update=functions.set_modified)
    timeStep : FloatProperty(name="Time step", default=0.001, update=functions.set_modified)
    fps : FloatProperty(name="FPS", default=120.0, update=functions.set_modified)
    maxTimeStep : FloatProperty(name="Max. time step", default=0.05, update=functions.set_modified)
    minTimeStep : FloatProperty(name="Min. time step", default=0.0, update=functions.set_modified)
    particleRadius : FloatProperty(name="Particle radius", default=0.0, update=functions.set_modified)
    gravity : FloatVectorProperty(name="Gravity", default=(0.0,0.0,-9.8), update=functions.set_modified)

    simulationMethod : EnumProperty(
        name="Method",
        items=types.solver_types,
        description="Pressure solver",
        default="wcsph_method",
        update=functions.set_modified
    )
    
    cflFactor : FloatProperty(name="CFL Factor", default=1.00, update=functions.set_modified)

    # WCSPH
    stiffness : FloatProperty(name="Stiffness", default=100.0, update=functions.set_modified)
    gamma : FloatProperty(name="Gamma", default=1.0, update=functions.set_modified)
    
    # PCISPH
    minIterationsPCI : IntProperty(name="Min. iterations", default=3, update=functions.set_modified)
    maxIterationsPCI : IntProperty(name="Max. iterations", default=100, update=functions.set_modified)
    etaPCI : FloatProperty(name="Density error", default=0.01, update=functions.set_modified)
    
    # DFSPH density
    minIterationsDF : IntProperty(name="Min. iterations", default=2, update=functions.set_modified)
    maxIterationsDF : IntProperty(name="Max. iterations", default=100, update=functions.set_modified)
    eta : FloatProperty(name="Density error", default=0.0005, update=functions.set_modified)
    
    # DFSPH divergence
    divSolver : BoolProperty(name="Diverence solver", default=True, update=functions.set_modified)
    minIterationsDFV : IntProperty(name="Min. iterations", default=1, update=functions.set_modified)
    maxIterationsDFV : IntProperty(name="Max. iterations", default=100, update=functions.set_modified)
    etaV : FloatProperty(name="Divergence error", default=0.001, update=functions.set_modified)
    

class FluidUnit(PropertyGroup):
    """ Representa una unidad de fluido: fluid box, emitter o geometry """
    
    def clear(self):
        if self.object is not None and self.fu_type != types.fluid_unit_types[1][0]:
            functions.deleteObject(self.object.name)
        if self.empty is not None:
            functions.deleteObject(self.empty.name)
    
    object : PointerProperty(name="", type=bpy.types.Object, update=functions.checkMeshFu)

    fu_type : EnumProperty(
        name="Fluid type",
        items=types.fluid_unit_types,
        description="Fluid unit type",
        default="fu_fluid_block_type",
        update=functions.set_modified
    )

    # Todo lo que viene en la clase a partir de aqui es exclusivamente de los emisores, encontrar la manera de separarlo
    # Cuidado con crear primitivas al actualizar un enum (tambian se actualiza cuando se cambia el valor desde el codigo ademas de en la interfaz)
    def update_emitter_enum(self, context):

        if self.emitter_type != types.emitter_types[0][0]:
            
            # guardar objeto activo antes de crear el emisor y el empty
            nameActiveObject = context.view_layer.objects.active.name
            
            # Añadir un empty para indicar la dirección del emisor
            bpy.ops.object.empty_add(type='SINGLE_ARROW', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            self.empty = context.view_layer.objects.active
            
            if self.emitter_type == types.emitter_types[1][0]: # Square

                # crear el plano
                bpy.ops.mesh.primitive_plane_add(size=1, enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(0.5, 0.5, 0.5))
                self.object = context.view_layer.objects.active
                self.object.name = "Square emitter"

            if self.emitter_type == types.emitter_types[2][0]: # Circle

                # crear el circulo y almacenarlo
                bpy.ops.mesh.primitive_circle_add(radius=0.5, enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(0.5, 0.5, 0.5))
                self.object = context.view_layer.objects.active
                self.object.name = "Circle emitter"

            # hacer al empty hijo del objeto emisor
            self.empty.parent = self.object

            # reestablecer el objeto activo
            context.view_layer.objects.active = bpy.data.objects[nameActiveObject]

    emitter_type : EnumProperty(
        name="Emitter type",
        items=types.emitter_types,
        description="Fluid unit type",
        default="none_emitter",
        update=update_emitter_enum
    )
    
    empty : PointerProperty(type=bpy.types.Object)

    velocity : FloatProperty(name="Velocity", default=0.2, update=functions.set_modified)
    spacing : FloatProperty(name="Spacing", default=1.0, update=functions.set_modified)
    numParticles: IntProperty(name="Number of particles", default=10000, update=functions.set_modified)
    startTime : FloatProperty(name="Emit start time", default=0.0, update=functions.set_modified)


class FluidModel(PropertyGroup):
    """Group of properties representing fluid model in the fluid Set list."""

    def clear(self):
        for fu in self.fm_list:
            fu.clear()            

    name : StringProperty(name="", default="Fluid model", update=functions.set_modified) # Cuidado no tiene nombre
    density0 : FloatProperty(name="Reference density", default=1000.0, update=functions.set_modified)
    viscosity : FloatProperty(name="Viscosity", default=0.01, update=functions.set_modified)
    bviscosity : FloatProperty(name="Boundary viscosity", default=0.0, update=functions.set_modified)
    surften : FloatProperty(name="Surface Tension", default=0.15, update=functions.set_modified)
    adhesion : FloatProperty(name="Adhesion", default=1.0, update=functions.set_modified)

    fm_list : CollectionProperty(type = FluidUnit)
    fu_index : IntProperty(name="Fluid unit index", default=0, update=functions.set_selected_fu)

    current_fu_type : EnumProperty(
        name="Fluid type",
        items=types.fluid_unit_types,
        description="Fluid unit type",
        default="fu_fluid_block_type",
        update=functions.set_modified
    )

class BoundaryUnit(PropertyGroup):
    
    def clear(self):
        if self.object is not None and self.bu_type != types.boundary_unit_types[2][0]:
            functions.deleteObject(self.object.name)

    # necesarias en pcisph boundary handling
    inverted: BoolProperty(name="Inverted", default=False, update=functions.set_modified)

    # necesario para la geometria
    spacing : FloatProperty(name="Spacing", default=0.7, update=functions.set_modified)

    object : PointerProperty(name="", type=bpy.types.Object, update=functions.checkMeshBu)

    bu_type : EnumProperty(
        name="Boundary type",
        items=types.boundary_unit_types,
        description="Boundary unit type",
        default="bu_box_type",
        update=functions.set_modified
    )



class BoundaryModel(PropertyGroup):

    def clear(self):
        for bu in self.bm_list:
            bu.clear()

    bm_list : CollectionProperty(type = BoundaryUnit)
    bu_index : IntProperty(name="Boundary unit index", default=0, update=functions.set_selected_bu)
    name : StringProperty(name="", default="Boundary model", update=functions.set_modified) # Cuidado no tiene nombre

    # necesario en pcisph boundary handling
    normalFct : FloatProperty(name="Normal conservation", default=0.0, update=functions.set_modified)
    tangFct : FloatProperty(name="Tangencial conservation", default=1.0, update=functions.set_modified)

    current_bu_type : EnumProperty(
        name="Boundary type",
        items=types.boundary_unit_types,
        description="Boundary unit type",
        default="bu_box_type",
        update=functions.set_modified
    )



class BoundarySet(PropertyGroup):
    
    def clear(self):
        for bm in self.bs_list:
            bm.clear()

    bs_list : CollectionProperty(type = BoundaryModel)
    bm_index : IntProperty(name="Boundary model index", default=0, update=functions.set_modified)

    boundaryMethod : EnumProperty(
        name="Boundary method",
        items=types.boundary_handling_types,
        description="Boundary handling Method",
        default="akinci_boundary_method",
        update=functions.set_modified
    )


class FluidSet(PropertyGroup):
    
    def clear(self):
        for fm in self.fs_list:
            fm.clear()

    viscosityMethod : EnumProperty(
        name="Viscosity Method",
        items=types.viscosity_types,
        description="Viscosity Method",
        default="artificial_visco_method",
        update=functions.set_modified
    )

    surftenMethod : EnumProperty(
        name="Surface Tension Method",
        items=types.surften_types,
        description="Surface Tension Method",
        default="akinci_st_method",
        update=functions.set_modified
    )

    adhesionMethod : EnumProperty(
        name="Adhesion Method",
        items=types.adhesion_types,
        description="Adhesion Method",
        default="none_adhesion_method",
        update=functions.set_modified
    )

    fs_list : CollectionProperty(name="List of fluid models", type = FluidModel)
    fm_index : IntProperty(name="Fluid model index", default=0, update=functions.set_modified)
    multiphase : BoolProperty(name="Multiphase simulation", default=False, update=functions.updateMultiphase)