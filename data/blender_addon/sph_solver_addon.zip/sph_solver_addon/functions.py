import bpy

def showMessageBox(title = "Message Box", icon = 'INFO', lines=""):
    def draw(self, context):
        for line in lines:
            self.layout.label(text=line)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

# Funcion de update para los elementos de la interfaz
def set_modified(self,context):
    context.object.sph_modified = True
    
def updateMultiphase(self, context):
    fluidSet = context.object.sph_fluid_set
    
    # Dejar solo un fluid model cuando se desactiva multiphase 
    # (o cambiar el indice a 0 simplemente y hacer que solo se exporte el fm 0)
    if fluidSet.multiphase == False:
        if len(fluidSet.fs_list) > 1:
            for i in range(1, len(fluidSet.fs_list)):
                fluidSet.fs_list.remove(1)
        elif len(fluidSet.fs_list) == 0:
            fluidSet.fs_list.add()
            
        fluidSet.fm_index = 0
    
def deleteObject(name):
    
    # Deselect all
    bpy.ops.object.select_all(action='DESELECT')

    # Buscar el objeto para ver si existe
    obj = bpy.context.view_layer.objects.get(name)

    if obj is not None: # Si el objeto existe, eliminar su empty y luego el objeto
        if obj.hide_get() == True:
            obj.hide_set(False)
        obj.select_set(True)
        bpy.ops.object.delete()

def set_selected_fu(self, context):
    
    fluidSet = context.object.sph_fluid_set
    fm_index = fluidSet.fm_index
    fm = fluidSet.fs_list[fm_index]
    fu_index = fm.fu_index
    fm_list = fm.fm_list
    fu = fm_list[fu_index]
    
    if fu.object is not None:
        bpy.ops.object.select_all(action='DESELECT')
        fu.object.select_set(True)

def set_selected_bu(self, context):
    
    boundarySet = context.object.sph_boundary_set
    bm_index = boundarySet.bm_index
    bm = boundarySet.bs_list[bm_index]
    bu_index = bm.bu_index
    bm_list = bm.bm_list
    bu = bm_list[bu_index]
    
    if bu.object is not None:
        bpy.ops.object.select_all(action='DESELECT')
        bu.object.select_set(True)
        
def checkMeshBu(self, context):
    
    boundarySet = context.object.sph_boundary_set
    bm_index = boundarySet.bm_index
    bm = boundarySet.bs_list[bm_index]
    bu_index = bm.bu_index
    bm_list = bm.bm_list
    bu = bm_list[bu_index]
    
    if bu.object is not None:
        if bu.object.type != 'MESH':
            showMessageBox("Warning", 'ERROR', ["Boundary unit must be a mesh"]) 
            bu.object = None
        
def checkMeshFu(self, context):
    
    fluidSet = context.object.sph_fluid_set
    fm_index = fluidSet.fm_index
    fm = fluidSet.fs_list[fm_index]
    fu_index = fm.fu_index
    fm_list = fm.fm_list
    fu = fm_list[fu_index]
    
    if fu.object is not None:
        if fu.object.type != 'MESH':
            showMessageBox("Warning", 'ERROR', ["Fluid unit must be a mesh"]) 
            fu.object = None
