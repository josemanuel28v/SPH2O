import json
import os
import bpy
from . import types
from . import functions

def read_frames(context, files, path):
    
    path = os.path.split(path)[0]
    filepath = os.path.join(path, files[0].name)
    numFiles = len(files)
    
    # Leer el primer frame para saber el numero de particulas
    numParticles = 0
    numActiveParticles = 0
    try:
        with open(filepath, 'r') as infile:
            state = json.load(infile)
            numParticles = state["numParticles"] 
            numActiveParticles = state["numActiveParticles"]
    except Exception as error: # Cuidado esto hace catch a cualquier tipo de excepcion
        print("Cannot start read", filepath)
    
    if numParticles > 0:
        context.scene.frame_end = len(files)

        ps_index = -1
        keys = context.object.particle_systems.keys()
        for i in range(0, len(keys)):
            if "SPHSystem" == keys[i]:
                ps_index = i
                break
            
        if ps_index > -1:
            p_sist = context.object.particle_systems['SPHSystem']
            context.object.particle_systems.active_index = ps_index
            bpy.ops.object.particle_system_remove()
            
        p_sist = context.object.modifiers.new("SPHSystem", 'PARTICLE_SYSTEM').particle_system
            
        # Establecer settings del sistema de particulas
        p_sist.settings.count = numParticles
        p_sist.settings.physics_type = 'NEWTON'
        p_sist.settings.emit_from = 'VERT'
        p_sist.settings.timestep = 0
        p_sist.settings.mass = 0
        p_sist.settings.normal_factor = 0
        p_sist.settings.frame_end = p_sist.settings.frame_start = 1
        p_sist.settings.lifetime = len(files)
        p_sist.particles.data.settings.display_size = context.object.sph_scene_data.particleRadius
        p_sist.settings.display_color = 'VELOCITY'
        p_sist.settings.color_maximum = 4
        
        # Limpiar cache
        fake_context = context.copy()
        fake_context["point_cache"] = p_sist.point_cache
        bpy.ops.ptcache.free_bake(fake_context)
 
        # Necesario para coger el psist actualizado
        degp = context.evaluated_depsgraph_get()
        p_sist = context.object.evaluated_get(degp).particle_systems[p_sist.name]
        
        # velocidades a 0 para que el integrador de blender no haga nada
        context.scene.frame_set(0)
        vel = [0,0,0] * numParticles
        p_sist.particles.foreach_set('velocity',vel)

        print("Start reading frames...")
        for file in files:
            filepath = os.path.join(path, file.name)
            split = file.name.split("_")
            split = split[1].split(".")
            frame = int(split[0])
            try:
                with open(filepath, 'r') as infile:
                    state = json.load(infile)
                    print("Inserting frame", str(frame) + "/" + str(numFiles), "in particle system", end="\r")
                    insert_frame(context.scene, frame, state, p_sist) 
            except Exception as error:
                stop = True
                print("")
                print("Cannot read", filepath)
        
        print("")  
        print("Frames read!")
        
        # bake cache
        bpy.ops.ptcache.bake_from_cache(fake_context)
        context.scene.frame_set(1)                
            

def insert_frame(scene, frame, state, p_sist): 
    # Numap debe ser menor que nump
    nump = state["numParticles"]
    numap = state["numActiveParticles"]
    
    scene.frame_set(frame)
    
    locations = [0,0,0] * nump
    for i in range(0, 3 * numap, 3):
        locations[i] = state["positions"][i//3][0]
        locations[i+1] = state["positions"][i//3][1]
        locations[i+2] = state["positions"][i//3][2]
        
    velocities = [0,0,0] * nump
    for i in range(0, 3 * numap, 3):
        velocities[i] = state["velocities"][i//3][0]
        velocities[i+1] = state["velocities"][i//3][1]
        velocities[i+2] = state["velocities"][i//3][2]
        
    # Hide inactive particles
    for i in range(3 * numap, 3 * nump, 3):
        locations[i] = 1000
        locations[i+1] = 1000
        locations[i+2] = 1000
    
    p_sist.particles.foreach_set("location", locations)
    p_sist.particles.foreach_set("velocity", velocities)
    

def import_config(object, filepath):

    with open(filepath, 'r') as infile:
        config = json.load(infile)
    
        print("Import scene data")
        import_scene(object, config)
        
        print("Import fluid set data")
        import_fluid_set(object, config)
        
        print("Import boundary set")
        import_boundary_set(object, config)
        
    return

def import_scene(object, config):
    
    sceneData = object.sph_scene_data
    boundarySet = object.sph_boundary_set
    
    simulationMethod = config["Configuration"]["simulationMethod"]        
    sceneData.simulationMethod = types.solver_types[simulationMethod][0]

    boundaryMethod = config["Configuration"]["boundaryMethod"]
    boundarySet.boundaryMethod = types.boundary_handling_types[boundaryMethod + 1][0]
    
    sceneData.startTime = config["Configuration"]["startTime"]
    sceneData.endTime = config["Configuration"]["endTime"]
    sceneData.timeStep = config["Configuration"]["timeStep"]
    sceneData.fps = config["Configuration"]["fps"]
    sceneData.minTimeStep = config["Configuration"]["minTimeStep"]
    sceneData.maxTimeStep = config["Configuration"]["maxTimeStep"]
    sceneData.particleRadius = config["Configuration"]["particleRadius"]
    sceneData.gravity = config["Configuration"]["gravity"]
    
    if sceneData.simulationMethod == types.solver_types[0][0]: # WCSPH
        sceneData.stiffness = config['Configuration']['stiffness']
        sceneData.gamma = config['Configuration']['gamma']
        sceneData.cflFactor = config['Configuration']['cflFactor']
    elif sceneData.simulationMethod == types.solver_types[1][0]: # PCISPH
        sceneData.etaPCI = config['Configuration']['eta']
        sceneData.minIterationsPCI = config['Configuration']['minIterations']
        sceneData.maxIterationsPCI = config['Configuration']['maxIterations']
        sceneData.cflFactor = config['Configuration']['cflFactor']
    elif sceneData.simulationMethod == types.solver_types[2][0]: # DFSPH
        sceneData.eta = config['Configuration']['eta']
        sceneData.minIterationsDF = config['Configuration']['minIterations']
        sceneData.maxIterationsDF = config['Configuration']['maxIterations']
        sceneData.etaV = config['Configuration']['etaV']
        sceneData.minIterationsDFV = config['Configuration']['minIterationsV']
        sceneData.maxIterationsDFV = config['Configuration']['maxIterationsV']
        sceneData.cflFactor = config['Configuration']['cflFactor']
    
def import_fluid_set(object, config):
    
    fluidSet = object.sph_fluid_set
    
    if "Fluid" in config.keys():
        
        viscosityMethod = config["Fluid"]["viscosityMethod"]
        fluidSet.viscosityMethod = types.viscosity_types[viscosityMethod + 1][0]

        surftenMethod = config["Fluid"]["surfaceTensionMethod"]
        if surftenMethod == -1:
            fluidSet.surftenMethod = types.surften_types[0][0]
        elif surftenMethod == 3:
            fluidSet.surftenMethod = types.surften_types[1][0]
        
        adhesionMethod = config["Fluid"]["adhesionMethod"]
        if adhesionMethod == -1:
            fluidSet.adhesionMethod == types.adhesion_types[0][0]
        elif adhesionMethod == 4:
            fluidSet.adhesionMethod == types.adhesion_types[1][0]
            
        # Fluid models
        for i in range(0, len(config["Fluid"]["FluidModel"])):
            fm = fluidSet.fs_list.add()
            fm.density0 = config["Fluid"]["FluidModel"][i]["density0"]
            fm.viscosity = config["Fluid"]["FluidModel"][i]["viscosity"]
            fm.bviscosity = config["Fluid"]["FluidModel"][i]["boundaryViscosity"]
            fm.surften = config["Fluid"]["FluidModel"][i]["surfaceTension"]
            fm.adhesion = config["Fluid"]["FluidModel"][i]["adhesion"]
            
            if "fluidBlocks" in config["Fluid"]["FluidModel"][i].keys():
                fluidBlocks = config["Fluid"]["FluidModel"][i]["fluidBlocks"]
                for j in range(0, len(fluidBlocks)):
                    fu = fm.fm_list.add()
                    
                    fu.min = fluidBlocks[j]["min"]
                    fu.max = fluidBlocks[j]["max"]
                    
                    x = (fu.max[0] + fu.min[0]) * 0.5
                    y = (fu.max[1] + fu.min[1]) * 0.5
                    z = (fu.max[2] + fu.min[2]) * 0.5
                    
                    dx = fu.max[0] - fu.min[0]
                    dy = fu.max[1] - fu.min[1]
                    dz = fu.max[2] - fu.min[2]
                    
                    # crear el fluid block
                    # guardar objeto activo antes de crear el nuevo cubo
                    nameActiveObject = bpy.context.view_layer.objects.active.name

                    # crear el cubo
                    bpy.ops.mesh.primitive_cube_add(size=0.5, enter_editmode=False, align="WORLD", location=(0, 0, 0), scale=(1, 1, 1))
                    bpy.context.view_layer.objects.active.name = "Fluid block"
                    fluidBlock = bpy.context.view_layer.objects.active
                    print("FluidBlock importado")
                    
                    # si no se establece el vector de golpe solo se asigna correctamente la ultima componente asignada
                    fluidBlock.location = (x, y, z)
                    fluidBlock.dimensions = (dx, dy, dz)

                    # Guardar en el fluid unit una referencia al objeto que lo representa y su tipo
                    fu.object = bpy.context.view_layer.objects.active
                    fu.fu_type = types.fluid_unit_types[0][0]

                    # reestablecer el objeto activo
                    bpy.context.view_layer.objects.active = bpy.data.objects[nameActiveObject]
            
            #elif "geometry" in config["Fluid"]["FluidModel"][i].keys():
            
            elif "emitters" in config["Fluid"]["FluidModel"][i].keys():
                emitters = config["Fluid"]["FluidModel"][i]["emitters"]
                
                for j in range(0, len(emitters)):
                    fu = fm.fm_list.add()
                    
                    fu.velocity = emitters[j]["velocity"]
                    fu.numParticles = emitters[j]["numParticles"]
                    fu.startTime = emitters[j]["startTime"]
                    fu.spacing = emitters[j]["spacing"]
                    
                    type = emitters[j]["type"]
                    fu.emitter_type = types.emitter_types[type + 1][0] # al establecer el tipo es cuando se crean los emitters por lo que no hay que crearlos manualmente
                    
                    if type == 0: # square
                        fu.object.dimensions = (emitters[j]["width"], emitters[j]["height"], 0)
                        fu.empty.scale.z = 0.5 * (emitters[j]["width"] + emitters[j]["height"])
                        
                    elif type == 1: # circle
                        fu.object.dimensions = (emitters[j]["width"] * 2.0, emitters[j]["width"] * 2.0, 0)
                        fu.empty.scale.z = emitters[j]["width"] * 2.0
                        
                    fu.object.location = (emitters[j]["position"][0], emitters[j]["position"][1], emitters[j]["position"][2])
                    
                    rotMode = fu.object.rotation_mode
                    fu.object.rotation_mode = 'QUATERNION'
                    fu.object.rotation_quaternion = (emitters[j]["rotation"][0], emitters[j]["rotation"][1], emitters[j]["rotation"][2], emitters[j]["rotation"][3])
                    fu.object.rotation_mode = rotMode
    else:
        # si no hay fluid, crear un fluid model ya que si no el addon se iniciara en no multifase sin ningun fm
        fluidSet = object.sph_fluid_set.fs_list.add()
        
def import_boundary_set(object, config):
    
    boundarySet = object.sph_boundary_set
    
    if "Boundary" in config.keys():
        
        # Boundary models
        for i in range(0, len(config["Boundary"])):
            bm = boundarySet.bs_list.add()
            
            if "box" in config["Boundary"][i].keys():
                boxes = config["Boundary"][i]["box"]
                for j in range(0, len(boxes)):
                    bu = bm.bm_list.add()
                    
                    bu.min = boxes[j]["min"]
                    bu.max = boxes[j]["max"]
                    
                    x = (bu.max[0] + bu.min[0]) * 0.5
                    y = (bu.max[1] + bu.min[1]) * 0.5
                    z = (bu.max[2] + bu.min[2]) * 0.5
                    
                    dx = bu.max[0] - bu.min[0]
                    dy = bu.max[1] - bu.min[1]
                    dz = bu.max[2] - bu.min[2]
      
                    # crear el box
                    # guardar objeto activo antes de crear el nuevo cubo
                    nameActiveObject = bpy.context.view_layer.objects.active.name

                    # crear el cubo
                    bpy.ops.mesh.primitive_cube_add(size=0.5, enter_editmode=False, align="WORLD", location=(0, 0, 0), scale=(1, 1, 1))
                    bpy.context.view_layer.objects.active.name = "Boundary cube"
                    box = bpy.context.view_layer.objects.active
                    print("box importado")
                    
                    # si no se establece el vector de golpe solo se asigna correctamente la ultima componente asignada
                    box.location = (x, y, z)
                    box.dimensions = (dx, dy, dz)

                    # Guardar en el fluid unit una referencia al objeto que lo representa y su tipo
                    bu.object = bpy.context.view_layer.objects.active
                    bu.bu_type = types.boundary_unit_types[0][0]

                    # reestablecer el objeto activo
                    bpy.context.view_layer.objects.active = bpy.data.objects[nameActiveObject]
                    
            if "sphere" in config["Boundary"][i].keys():
                spheres = config["Boundary"][i]["sphere"]
                for j in range(0, len(spheres)):
                    bu = bm.bm_list.add()
                    
                    # crear el sphere
                    # guardar objeto activo antes de crear el nuevo cubo
                    nameActiveObject = bpy.context.view_layer.objects.active.name

                    # crear el cubo
                    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.5, enter_editmode=False, align="WORLD", location=(0, 0, 0), scale=(1, 1, 1))
                    bpy.context.view_layer.objects.active.name = "Boundary sphere"
                    sphere = bpy.context.view_layer.objects.active
                    print("sphere importado")
                    
                    # si no se establece el vector de golpe solo se asigna correctamente la ultima componente asignada
                    location = spheres[j]["pos"]
                    radius = spheres[j]["radius"]
                    sphere.location = (location[0], location[1], location[2])
                    sphere.dimensions = (radius * 2.0, radius * 2.0, radius * 2.0)

                    # Guardar en el fluid unit una referencia al objeto que lo representa y su tipo
                    bu.object = bpy.context.view_layer.objects.active
                    bu.bu_type = types.boundary_unit_types[1][0]

                    # reestablecer el objeto activo
                    bpy.context.view_layer.objects.active = bpy.data.objects[nameActiveObject]
                    
            if "geometry" in config["Boundary"][i].keys():
                geometries = config["Boundary"][i]["geometry"]
                
                for j in range(0, len(geometries)):
                    
                    spacing = geometries[j]["spacing"]
                    path = geometries[j]["path"]
                    
                    try:
                        bpy.ops.import_scene.obj(filepath=path)
                    except (RuntimeError, FileNotFoundError) as e:
                        print("ERROR: File " + path + " not found")
                        dir = os.path.split(path)[0]
                        line1 = "File " + path + " not found."
                        line2 =  "Put the .obj in the directory " + dir + " or add it manually."
                        functions.showMessageBox(title = "File not found", icon = 'ERROR', lines = (line1, line2))
                    
                    #coger el objeto importado y asignarlo a bu.object
                    bu = bm.bm_list.add()    
                    bu.bu_type = types.boundary_unit_types[2][0]
                

def export_config(object):

    config = {}

    # Scene data
    export_scene(object, config)

    # Fluid set
    export_fluid_set(object, config)

    # Boundary set
    export_boundary_set(object, config)
    
    split = os.path.split(bpy.data.filepath)
    path = split[0]
    filename = split[1]
    filename = filename[:-6] + ".json"

    with open(os.path.join(path, filename), 'w') as outfile:
        json.dump(config, outfile, indent=4)
        print("Exported scene")
        outfile.close()

    return {"FINISHED"}

def export_scene(object, config):

    sceneData = object.sph_scene_data
    boundarySetData = object.sph_boundary_set

    simulationMethod = -1
    if sceneData.simulationMethod == types.solver_types[0][0]: # WCSPH
        simulationMethod = 0
    elif sceneData.simulationMethod == types.solver_types[1][0]: # PCISPH
        simulationMethod = 1
    elif sceneData.simulationMethod == types.solver_types[2][0]: # DFSPH
        simulationMethod = 2

    boundaryMethod = -1
    if boundarySetData.boundaryMethod == types.boundary_handling_types[1][0]: # Simple cube bh
        boundaryMethod = 0
    elif boundarySetData.boundaryMethod == types.boundary_handling_types[2][0]: # PCISPH bh
        boundaryMethod = 1
    if boundarySetData.boundaryMethod == types.boundary_handling_types[3][0]: # Akinci bh
        boundaryMethod = 2

    config['Configuration'] = {

        "startTime" : sceneData.startTime,
        "endTime":sceneData.endTime,
        "timeStep":sceneData.timeStep,
        "fps":sceneData.fps,
        "minTimeStep":sceneData.minTimeStep,
        "maxTimeStep":sceneData.maxTimeStep,

        "gravity":[sceneData.gravity[0],sceneData.gravity[1],sceneData.gravity[2]],
        "particleRadius":sceneData.particleRadius,
        "simulationMethod":simulationMethod,
        "boundaryMethod":boundaryMethod,
    }

    # Solver data
    if sceneData.simulationMethod == types.solver_types[0][0]: # WCSPH
        config['Configuration']['stiffness'] = sceneData.stiffness
        config['Configuration']['gamma'] = sceneData.gamma
        config['Configuration']['cflFactor'] = sceneData.cflFactor
    elif sceneData.simulationMethod == types.solver_types[1][0]: # PCISPH
        config['Configuration']['eta'] = sceneData.etaPCI
        config['Configuration']['minIterations'] = sceneData.minIterationsPCI
        config['Configuration']['maxIterations'] = sceneData.maxIterationsPCI
        config['Configuration']['cflFactor'] = sceneData.cflFactor
    elif sceneData.simulationMethod == types.solver_types[2][0]: # DFSPH
        config['Configuration']['eta'] = sceneData.eta
        config['Configuration']['minIterations'] = sceneData.minIterationsDF
        config['Configuration']['maxIterations'] = sceneData.maxIterationsDF
        config['Configuration']['etaV'] = sceneData.etaV
        config['Configuration']['minIterationsV'] = sceneData.minIterationsDFV
        config['Configuration']['maxIterationsV'] = sceneData.maxIterationsDFV
        config['Configuration']['cflFactor'] = sceneData.cflFactor

def export_fluid_set(object, config):

    fluidSetData = object.sph_fluid_set

    viscosityMethod = -1
    if fluidSetData.viscosityMethod == types.viscosity_types[1][0]: # Standard visco
        viscosityMethod = 0
    elif fluidSetData.viscosityMethod == types.viscosity_types[2][0]: # Artificial visco
        viscosityMethod = 1
    elif fluidSetData.viscosityMethod == types.viscosity_types[3][0]: # XSPH visco
        viscosityMethod = 2

    surftenMethod = -1
    if fluidSetData.surftenMethod == types.surften_types[1][0]: # Akinci surface tension
        surftenMethod = 3

    adhesionMethod = -1
    if fluidSetData.adhesionMethod == types.adhesion_types[1][0]: # Adhesion
        adhesionMethod = 4

    fluidSet = {}

    for fm in fluidSetData.fs_list:

        if len(fm.fm_list) > 0: 

            fluidSet['FluidModel'] = []
                
            fluidBlocks = []
            #geometry = []
            emitters = []

            for fu in fm.fm_list:

                if fu.fu_type == types.fluid_unit_types[0][0]: # fluid block

                    sideX = fu.object.dimensions[0]
                    sideY = fu.object.dimensions[1]
                    sideZ = fu.object.dimensions[2]

                    x = fu.object.location[0]
                    y = fu.object.location[1]
                    z = fu.object.location[2]

                    min = [x - sideX * 0.5,
                           y - sideY * 0.5,
                           z - sideZ * 0.5]
                    max = [x + sideX * 0.5,
                           y + sideY * 0.5,
                           z + sideZ * 0.5]

                    fluidBlock = {
                        "min":min,
                        "max":max
                    }

                    fluidBlocks.append(fluidBlock)

                #elif fu.fu_type == fluid_unit_types[1][0]: # geometry

                    # Hay que exportar las geometrias en formato obj en determinada ruta
                    # Aun no se ha implementado el sampleo de volumen en el simulador por lo que de momento nada

                elif fu.fu_type == types.fluid_unit_types[2][0]: # emitter

                    if fu.emitter_type != types.emitter_types[0][0]: # si es distinto de none

                        emitter = {
                            "velocity":fu.velocity,
                            "numParticles":fu.numParticles,
                            "startTime":fu.startTime,
                            "spacing":fu.spacing
                        }

                        x = fu.object.location[0]
                        y = fu.object.location[1]
                        z = fu.object.location[2]

                        emitter['position'] = [x, y, z]
                        
                        quat = fu.object.rotation_euler.to_quaternion()

                        w = quat[0]
                        x = quat[1]
                        y = quat[2]
                        z = quat[3]

                        emitter['rotation'] = [w, x, y, z]

                        if fu.emitter_type == types.emitter_types[1][0]: # square emitter

                            emitter['type'] = 0
                            emitter['width'] = fu.object.dimensions[0]
                            emitter['height'] = fu.object.dimensions[1]

                        elif fu.emitter_type == types.emitter_types[2][0]: # circle emitter

                            emitter['type'] = 1
                            emitter['width'] = fu.object.dimensions[0] * 0.5
                            emitter['height'] = emitter['width']

                        emitters.append(emitter)
                        
            if len(fluidBlocks) > 0 or len(emitters) > 0 or '''len(geometry) > 0''':

                fluidModel = {
                    "viscosity": fm.viscosity,
                    "boundaryViscosity": fm.bviscosity,
                    "surfaceTension": fm.surften,
                    "adhesion": fm.adhesion,
                    "density0": fm.density0,
                }

                if len(fluidBlocks) > 0 :
                    fluidModel['fluidBlocks'] = fluidBlocks
                #if len(geometry) > 0 :
                    #fluidModel['geometry'] = []
                if len(emitters) > 0:
                    fluidModel['emitters'] = emitters
                    
                fluidSet['FluidModel'].append(fluidModel)

    if 'FluidModel' in fluidSet.keys():
        
        config['Fluid'] = {
        "viscosityMethod": viscosityMethod,
        "surfaceTensionMethod": surftenMethod,
        "adhesionMethod": adhesionMethod,
        "FluidModel": fluidSet['FluidModel']
    }

def export_boundary_set(object, config):

    boundarySetData = object.sph_boundary_set
    boundaryMethod = object.sph_boundary_set.boundaryMethod

    boundarySet = []

    for bm in boundarySetData.bs_list:

        if len(bm.bm_list) > 0:

            boundaryModel = {}

            if boundaryMethod == types.boundary_handling_types[2][0]: # pcisph boundary handling
                boundaryModel['normalFct'] = bm.normalFct
                boundaryModel['tangFct'] = bm.tangFct

            boxes = []
            spheres = []
            geometries = []

            for bu in bm.bm_list:

                if bu.bu_type == types.boundary_unit_types[0][0]: # box

                    sideX = bu.object.dimensions[0]
                    sideY = bu.object.dimensions[1]
                    sideZ = bu.object.dimensions[2]

                    x = bu.object.location[0]
                    y = bu.object.location[1]
                    z = bu.object.location[2]

                    min = [x - sideX * 0.5,
                           y - sideY * 0.5,
                           z - sideZ * 0.5]
                    max = [x + sideX * 0.5,
                           y + sideY * 0.5,
                           z + sideZ * 0.5]

                    box = {
                        "min":min,
                        "max":max
                    }

                    if boundaryMethod == types.boundary_handling_types[2][0]: # pcisph boundary handling
                        box['inverted'] = bu.inverted

                    boxes.append(box)

                elif bu.bu_type == types.boundary_unit_types[1][0]: # sphere

                    x = bu.object.location[0]
                    y = bu.object.location[1]
                    z = bu.object.location[2]

                    sphere = {
                        "pos": [x, y, z],
                        "radius": bu.object.dimensions[0] * 0.5
                    }

                    if boundaryMethod == types.boundary_handling_types[2][0]: # pcisph boundary handling
                        sphere['inverted'] = bu.inverted

                    spheres.append(sphere)

                elif bu.bu_type == types.boundary_unit_types[2][0]: # geometry
                    
                    if bu.object is not None:
                        
                        bpy.ops.object.select_all(action='DESELECT')
                        bu.object.select_set(True)
                        
                        blend_file_path = bpy.data.filepath
                        directory = os.path.dirname(blend_file_path)
                        directory = os.path.join(directory, 'Models')
                        if os.path.isdir(directory) is False:
                            os.mkdir(directory)
                        target_file = os.path.join(directory, bu.object.name + '.obj')
                        
                        # Exportar obj
                        bpy.ops.export_scene.obj(filepath=target_file, use_selection=True, use_materials=False)
                        
                        geometry = {
                            "path": target_file,
                            "spacing": bu.spacing
                        }

                        geometries.append(geometry)

            if len(boxes) > 0 or len(spheres) > 0 or len(geometries) > 0:

                if len(boxes) > 0 :
                    boundaryModel['box'] = boxes
                if len(spheres) > 0:
                    boundaryModel['sphere'] = spheres
                if len(geometries) > 0 :
                    boundaryModel['geometry'] = geometries

                boundarySet.append(boundaryModel)


    if len(boundarySet) > 0:
        config['Boundary'] = []
        config['Boundary'] = boundarySet


